# Use a bootstrap driven / compatible theme
E.g. Simple Bootstrap

# Sidebars per page
Custom Sidebars plugin

# Make shortcode work in sidebar text-widget
Shortcode widget plugin
http://www.wpbeginner.com/wp-tutorials/how-to-use-shortcodes-in-your-wordpress-sidebar-widgets/

# Use shortcodes
The following example shows an 

    [entryscape component="viewMetadata" template="dcat:OnlyDataset"]
    
# Multilanguage

See instructions: http://www.wpbeginner.com/beginners-guide/how-to-easily-create-a-multilingual-wordpress-site/

The polylang plugin works well. 

To allow the same slug (page id in URL) for different languages install the following plugin:
https://github.com/grappler/polylang-slug